
#ifndef __USB_APP_DEF_H
#define __USB_APP_DEF_H






void USB_Init(void);


#endif

